using System;
using System.IO;
using System.Windows.Forms;

namespace Editor_de_Texto
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Cria e carrega o dicion�rio na inicializa��o (se existir arquivo dicionario.txt)
            teste_Dicionario dicionario = new teste_Dicionario();
            string caminho = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Palvras em Portugues.txt");
            try
            {
                if (File.Exists(caminho))
                {
                    dicionario.CarregarDeArquivo(caminho);
                    Console.WriteLine("Dicion�rio carregado de: " + caminho);
                }
                else
                {
                    Console.WriteLine("Arquivo de dicion�rio n�o encontrado em: " + caminho);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Erro ao carregar dicion�rio: " + ex.Message);
            }

            Application.Run(new Form1(dicionario));
        }
    }
}
