using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO; // Importando System.IO para usar operações relacionadas a arquivos

namespace Editor_de_Texto
{
    // Definição da classe Dicionario
    public class Dicionario
    {
        // Campo privado que armazena um array de objetos ListaDuplamenteEncadeada, representando a tabela hash
        private ListaDuplamenteEncadeada[] tabelaHash;
        // Constante que define o tamanho da tabela hash
        private const int TAMANHO_TABELA = 100;

        // Construtor que inicializa a tabela hash
        public Dicionario()
        {
            tabelaHash = new ListaDuplamenteEncadeada[TAMANHO_TABELA];
            // Inicializa cada entrada na tabela hash com um novo objeto ListaDuplamenteEncadeada
            for (int i = 0; i < TAMANHO_TABELA; i++)
            {
                tabelaHash[i] = new ListaDuplamenteEncadeada();
            }
        }

        // Método para obter o código hash para uma determinada palavra
        private int ObterHash(string palavra)
        {
            return Math.Abs(palavra.GetHashCode() % TAMANHO_TABELA);
        }

        // Método para adicionar uma palavra ao dicionário
        public void AdicionarPalavra(string palavra)
        {
            int hash = ObterHash(palavra);
            // Adiciona a palavra à lista correspondente no hash, se ela ainda não estiver presente
            if (!tabelaHash[hash].Contem(palavra))
            {
                tabelaHash[hash].Adicionar(palavra);
            }
        }

        // Método para verificar se uma palavra está no dicionário
        public bool ContemPalavra(string palavra)
        {
            int hash = ObterHash(palavra);
            return tabelaHash[hash].Contem(palavra);
        }

        // Método para remover uma palavra do dicionário
        public void RemoverPalavra(string palavra)
        {
            int hash = ObterHash(palavra);
            tabelaHash[hash].Remover(palavra);
        }

        // Método para carregar palavras de um arquivo
        public void CarregarDeArquivo(string caminho)
        {
            foreach (string linha in File.ReadLines(caminho))
            {
                AdicionarPalavra(linha.Trim());
            }
        }

        public List<string> OrdenarBolha()
        {
            // Coleta todas as palavras da tabela hash em uma única lista
            List<string> todasPalavras = new List<string>();
            for (int i = 0; i < TAMANHO_TABELA; i++)
            {
                foreach (var palavra in tabelaHash[i].ObterTodos())
                {
                    todasPalavras.Add(palavra);
                }
            }

            // Aplica o algoritmo de ordenação bolha (Bubble Sort)
            int n = todasPalavras.Count;
            bool trocou;

            do
            {
                trocou = false;
                for (int i = 0; i < n - 1; i++)
                {
                    if (string.Compare(todasPalavras[i], todasPalavras[i + 1], StringComparison.OrdinalIgnoreCase) > 0)
                    {
                        string temp = todasPalavras[i];
                        todasPalavras[i] = todasPalavras[i + 1];
                        todasPalavras[i + 1] = temp;
                        trocou = true;
                    }
                }
                n--; // Otimização: último elemento já está na posição correta
            } while (trocou);

            return todasPalavras;
        }

        public List<string> OrdenarHeap()
        {
            // Coleta todas as palavras da tabela hash em uma única lista
            List<string> todasPalavras = new List<string>();
            for (int i = 0; i < TAMANHO_TABELA; i++)
            {
                foreach (var palavra in tabelaHash[i].ObterTodos())
                {
                    todasPalavras.Add(palavra);
                }
            }

            int n = todasPalavras.Count;

            // Constrói o heap (reorganiza a lista)
            for (int i = n / 2 - 1; i >= 0; i--)
                Heapify(todasPalavras, n, i);

            // Extrai elementos do heap um por um
            for (int i = n - 1; i > 0; i--)
            {
                // Move a raiz (maior elemento) para o final
                string temp = todasPalavras[0];
                todasPalavras[0] = todasPalavras[i];
                todasPalavras[i] = temp;

                // Chama Heapify na parte reduzida do heap
                Heapify(todasPalavras, i, 0);
            }

            return todasPalavras;
        }

        // =============================================================
        // 🔸 MÉTODO AUXILIAR PRIVADO: Função Heapify
        // =============================================================
        private void Heapify(List<string> lista, int tamanho, int i)
        {
            int maior = i;          // Inicializa o maior como raiz
            int esquerda = 2 * i + 1;
            int direita = 2 * i + 2;

            // Se o filho da esquerda é maior que a raiz
            if (esquerda < tamanho && string.Compare(lista[esquerda], lista[maior], StringComparison.OrdinalIgnoreCase) > 0)
                maior = esquerda;

            // Se o filho da direita é maior que o maior até agora
            if (direita < tamanho && string.Compare(lista[direita], lista[maior], StringComparison.OrdinalIgnoreCase) > 0)
                maior = direita;

            // Se o maior não é a raiz
            if (maior != i)
            {
                string troca = lista[i];
                lista[i] = lista[maior];
                lista[maior] = troca;

                // Recursivamente aplica Heapify na subárvore afetada
                Heapify(lista, tamanho, maior);
            }
        }

        public List<string> OrdenarInsercao()
        {
            // Coleta todas as palavras da tabela hash em uma única lista
            List<string> todasPalavras = new List<string>();
            for (int i = 0; i < TAMANHO_TABELA; i++)
            {
                foreach (var palavra in tabelaHash[i].ObterTodos())
                {
                    todasPalavras.Add(palavra);
                }
            }

            // Aplica o algoritmo de ordenação por inserção (Insertion Sort)
            for (int i = 1; i < todasPalavras.Count; i++)
            {
                string chave = todasPalavras[i];
                int j = i - 1;

                // Move elementos maiores que a chave uma posição à frente
                while (j >= 0 && string.Compare(todasPalavras[j], chave, StringComparison.OrdinalIgnoreCase) > 0)
                {
                    todasPalavras[j + 1] = todasPalavras[j];
                    j--;
                }

                todasPalavras[j + 1] = chave;
            }

            return todasPalavras;
        }

        // Método para salvar as palavras do dicionário em um arquivo
        public void SalvarEmArquivo(string caminho)
        {
            using (StreamWriter escritor = new StreamWriter(caminho))
            {
                for (int i = 0; i < TAMANHO_TABELA; i++)
                {
                    foreach (var palavra in tabelaHash[i].ObterTodos())
                    {
                        escritor.WriteLine(palavra);
                    }
                }
            }
        }
    }
}
