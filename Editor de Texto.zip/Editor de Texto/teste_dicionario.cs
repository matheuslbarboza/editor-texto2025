﻿using System;
using System.IO;
using System.Linq;

namespace Editor_de_Texto
{
    public class teste_Dicionario
    {
        private string[] palavras;
        private int tamanhoAtual;

        public teste_Dicionario(int capacidadeInicial = 100)
        {
            palavras = new string[capacidadeInicial];
            tamanhoAtual = 0;
        }

        // Adiciona uma palavra ao vetor (expande se necessário)
        public void AdicionarPalavra(string palavra)
        {
            if (string.IsNullOrWhiteSpace(palavra)) return;

            palavra = palavra.Trim();

            // Verifica se já existe (case-insensitive)
            if (palavras.Contains(palavra, StringComparer.OrdinalIgnoreCase))
                return;

            // Se o vetor está cheio, expande o tamanho
            if (tamanhoAtual == palavras.Length)
            {
                Array.Resize(ref palavras, palavras.Length * 2);
            }

            palavras[tamanhoAtual++] = palavra;
        }

        // Verifica se contém a palavra (case-insensitive)
        public bool Contem(string palavra)
        {
            if (string.IsNullOrWhiteSpace(palavra)) return false;
            return palavras.Contains(palavra.Trim(), StringComparer.OrdinalIgnoreCase);
        }

        // Remove uma palavra (retorna true se removida)
        public bool RemoverPalavra(string palavra)
        {
            if (string.IsNullOrWhiteSpace(palavra)) return false;

            int idx = Array.FindIndex(palavras, 0, tamanhoAtual, p => string.Equals(p, palavra.Trim(), StringComparison.OrdinalIgnoreCase));
            if (idx >= 0)
            {
                // Desloca os elementos para remover a palavra
                for (int i = idx; i < tamanhoAtual - 1; i++)
                {
                    palavras[i] = palavras[i + 1];
                }
                palavras[--tamanhoAtual] = null;
                return true;
            }
            return false;
        }

        // Retorna todos os elementos
        public string[] ObterTodos()
        {
            return palavras.Take(tamanhoAtual).ToArray();
        }

        // Carrega arquivo
        public void CarregarDeArquivo(string caminhoArquivo)
        {
            if (!File.Exists(caminhoArquivo))
                throw new FileNotFoundException($"Arquivo não encontrado: {caminhoArquivo}");

            string[] linhas = File.ReadAllLines(caminhoArquivo);
            foreach (var linha in linhas)
            {
                var palavra = linha?.Trim();
                if (!string.IsNullOrEmpty(palavra))
                    AdicionarPalavra(palavra);
            }
        }

        // Salvar em arquivo (uma palavra por linha)
        public void SalvarEmArquivo(string caminhoArquivo)
        {
            using (var escritor = new StreamWriter(caminhoArquivo, false))
            {
                for (int i = 0; i < tamanhoAtual; i++)
                {
                    escritor.WriteLine(palavras[i]);
                }
            }
        }

        // ===========================
        // Algoritmos de ordenação
        // ===========================

        public string[] OrdenarBolha()
        {
            string[] lista = new string[tamanhoAtual];
            Array.Copy(palavras, lista, tamanhoAtual);
            int n = lista.Length;
            bool trocou;
            do
            {
                trocou = false;
                for (int i = 0; i < n - 1; i++)
                {
                    if (string.Compare(lista[i], lista[i + 1], StringComparison.OrdinalIgnoreCase) > 0)
                    {
                        var tmp = lista[i];
                        lista[i] = lista[i + 1];
                        lista[i + 1] = tmp;
                        trocou = true;
                    }
                }
                n--;
            } while (trocou);
            return lista;
        }

        public string[] OrdenarInsercao()
        {
            string[] lista = new string[tamanhoAtual];
            Array.Copy(palavras, lista, tamanhoAtual);
            for (int i = 1; i < lista.Length; i++)
            {
                string chave = lista[i];
                int j = i - 1;
                while (j >= 0 && string.Compare(lista[j], chave, StringComparison.OrdinalIgnoreCase) > 0)
                {
                    lista[j + 1] = lista[j];
                    j--;
                }
                lista[j + 1] = chave;
            }
            return lista;
        }

        public string[] OrdenarHeap()
        {
            string[] lista = new string[tamanhoAtual];
            Array.Copy(palavras, lista, tamanhoAtual);
            int n = lista.Length;

            for (int i = n / 2 - 1; i >= 0; i--)
                Heapify(lista, n, i);

            for (int i = n - 1; i > 0; i--)
            {
                var tmp = lista[0];
                lista[0] = lista[i];
                lista[i] = tmp;
                Heapify(lista, i, 0);
            }

            return lista;
        }

        private void Heapify(string[] lista, int tamanho, int i)
        {
            int maior = i;
            int left = 2 * i + 1;
            int right = 2 * i + 2;

            if (left < tamanho && string.Compare(lista[left], lista[maior], StringComparison.OrdinalIgnoreCase) > 0)
                maior = left;

            if (right < tamanho && string.Compare(lista[right], lista[maior], StringComparison.OrdinalIgnoreCase) > 0)
                maior = right;

            if (maior != i)
            {
                var tmp = lista[i];
                lista[i] = lista[maior];
                lista[maior] = tmp;
                Heapify(lista, tamanho, maior);
            }
        }
    }
}